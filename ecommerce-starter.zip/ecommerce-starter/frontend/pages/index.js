import axios from 'axios';
import Link from 'next/link';
import Header from '../components/Header';

export default function Home({ products }) {
  return (
    <div>
      <Header />
      <main className="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
        {products.map(p => (
          <div key={p.id} className="bg-white p-4 rounded shadow">
            <h2 className="font-semibold">{p.name}</h2>
            <p className="text-sm">Price: ${(p.price/100).toFixed(2)}</p>
            <Link href={`/product/${p.id}`}><button className="mt-4 px-3 py-1 bg-blue-600 text-white rounded">View</button></Link>
          </div>
        ))}
      </main>
    </div>
  );
}

export async function getServerSideProps(){
  const res = await axios.get(`${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:4000'}/api/products`);
  return { props: { products: res.data.products } };
}
