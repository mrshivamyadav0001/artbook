import axios from 'axios';
import Header from '../../components/Header';
import { useState } from 'react';

export default function Product({ product }){
  const [qty, setQty] = useState(1);

  async function addToCart(){
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    cart.push({ productId: product.id, qty });
    localStorage.setItem('cart', JSON.stringify(cart));
    alert('Added to cart');
  }

  return (
    <>
      <Header />
      <div className="p-6">
        <h1 className="text-2xl font-bold">{product.name}</h1>
        <p className="my-2">Price: ${(product.price/100).toFixed(2)}</p>
        <div>
          <label>Qty: </label>
          <input type="number" value={qty} onChange={e=>setQty(Number(e.target.value))} min={1} className="border p-1 w-20" />
          <button onClick={addToCart} className="ml-2 px-3 py-1 bg-green-600 text-white rounded">Add</button>
        </div>
      </div>
    </>
  );
}

export async function getServerSideProps({ params }){
  const res = await axios.get(`${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:4000'}/api/products/${params.id}`);
  return { props: { product: res.data } };
}
