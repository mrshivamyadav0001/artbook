import Header from '../components/Header';
import axios from 'axios';
import { useEffect, useState } from 'react';

export default function Cart(){
  const [cart, setCart] = useState([]);
  const [items, setItems] = useState([]);

  useEffect(()=> {
    const c = JSON.parse(localStorage.getItem('cart') || '[]');
    setCart(c);
    if(c.length) {
      const fetch = async ()=>{
        const proms = c.map(ci => axios.get(`${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:4000'}/api/products/${ci.productId}`));
        const res = await Promise.all(proms);
        setItems(res.map((r, idx) => ({ ...r.data, qty: c[idx].qty })));
      }
      fetch();
    }
  }, []);

  async function checkout(){
    const payload = { items: cart, email: '' };
    const res = await axios.post(`${process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:4000'}/api/checkout/create-session`, payload);
    if (res.data.url) {
      window.location.href = res.data.url;
    } else {
      alert('Error creating checkout');
    }
  }

  return (
    <>
      <Header />
      <main className="p-6">
        <h2 className="text-xl font-semibold">Cart</h2>
        {items.length === 0 ? <p>Cart is empty</p> : (
          <div>
            {items.map(it => (
              <div key={it.id} className="p-2 border-b flex justify-between">
                <div>
                  <div className="font-medium">{it.name}</div>
                  <div>Qty: {it.qty}</div>
                </div>
                <div>${(it.price/100 * it.qty).toFixed(2)}</div>
              </div>
            ))}
            <button onClick={checkout} className="mt-4 px-4 py-2 bg-blue-600 text-white rounded">Checkout with Stripe</button>
          </div>
        )}
      </main>
    </>
  );
}
