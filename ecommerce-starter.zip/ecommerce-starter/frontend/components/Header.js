import Link from 'next/link';
export default function Header() {
  return (
    <header className="p-4 bg-white shadow-sm flex justify-between">
      <h1 className="text-xl font-semibold"><Link href="/">MyShop</Link></h1>
      <nav className="space-x-4">
        <Link href="/">Shop</Link>
        <Link href="/cart">Cart</Link>
      </nav>
    </header>
  );
}
