ecommerce-starter (frontend + backend)
------------------------------------
Backend (Express + Prisma + Stripe):
  - cd backend
  - cp .env.example .env  (fill DATABASE_URL, STRIPE keys)
  - npm install
  - npx prisma generate
  - npx prisma migrate dev --name init
  - npm run seed
  - npm run dev

Frontend (Next.js + Tailwind):
  - cd frontend
  - npm install
  - npm run dev

Notes:
  - Use ngrok to expose backend /webhook to Stripe for webhook testing.
  - This is a minimal starter. Don't use secrets in production.
