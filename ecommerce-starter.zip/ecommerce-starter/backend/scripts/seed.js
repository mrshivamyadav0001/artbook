const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
async function main(){
  await prisma.product.createMany({
    data: [
      { name: 'Handmade Pottery', price: 2500, description: 'Beautiful pottery', images: [], stock: 10 },
      { name: 'Kantha Scarf', price: 1800, description: 'Soft scarf', images: [], stock: 5 }
    ]
  });
  console.log('Seed done');
}
main().catch(e=>console.error(e)).finally(()=>prisma.$disconnect());
